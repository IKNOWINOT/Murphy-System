#!/usr/bin/env python3
"""
Add LLM API endpoints to murphy_backend_complete.py with proper escaping.
"""

# Read the file
with open('/workspace/murphy_backend_complete.py', 'r') as f:
    lines = f.readlines()

# Find and remove the corrupted LLM endpoints section
start_marker = "# LLM API ENDPOINTS"
end_marker = "# SERVER STARTUP"

start_index = None
end_index = None

for i, line in enumerate(lines):
    if start_marker in line:
        start_index = i
    if end_marker in line:
        end_index = i
        break

if start_index is not None and end_index is not None:
    # Remove the corrupted section
    lines = lines[:start_index] + lines[end_index:]
    print(f"✓ Removed corrupted LLM endpoints (lines {start_index}-{end_index})")
else:
    print("✗ Could not find LLM endpoints section")
    exit(1)

# Now add clean endpoints
# Find SERVER STARTUP again
insert_index = None
for i, line in enumerate(lines):
    if "# SERVER STARTUP" in line:
        insert_index = i
        break

if insert_index is None:
    print("Could not find SERVER STARTUP section")
    exit(1)

# Clean endpoints with proper escaping
llm_endpoints = '''
# ============================================================================
# LLM API ENDPOINTS
# ============================================================================

@app.route('/api/llm/generate', methods=['POST'])
def llm_generate():
    """Generate LLM response."""
    try:
        data = request.get_json()
        prompt = data.get('prompt', '')
        
        if not prompt:
            return jsonify({
                'success': False,
                'error': 'No prompt provided'
            }), 400
        
        if not LLM_AVAILABLE or not llm_manager:
            return jsonify({
                'success': False,
                'error': 'LLM system not available'
            }), 500
        
        result = llm_manager.generate(prompt)
        
        return jsonify({
            'success': result['success'],
            'response': result['response'],
            'provider': result['provider'],
            'demo_mode': result['demo_mode']
        })
    
    except Exception as e:
        logger.error(f"LLM generate error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/llm/status', methods=['GET'])
def llm_status():
    """Get LLM system status."""
    try:
        if not LLM_AVAILABLE or not llm_manager:
            return jsonify({
                'success': False,
                'available': False,
                'providers': []
            })
        
        status = llm_manager.get_status()
        
        return jsonify({
            'success': True,
            'available': True,
            'total_providers': status['total_providers'],
            'available_providers': status['available_providers'],
            'providers': status['providers']
        })
    
    except Exception as e:
        logger.error(f"LLM status error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


'''

lines.insert(insert_index, llm_endpoints)

# Write back
with open('/workspace/murphy_backend_complete.py', 'w') as f:
    f.writelines(lines)

print(f"✓ LLM endpoints added at line {insert_index}")