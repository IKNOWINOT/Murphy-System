"""
Credential Verification Interface
Provides unified interface for credential verification across different services.
"""

from typing import Dict, List, Optional, Any, Protocol
from datetime import datetime, timedelta
from enum import Enum
from pydantic import BaseModel, Field
from abc import ABC, abstractmethod

from murphy_implementation.validation.credential_verifier import (
    Credential, CredentialType, CredentialStatus, CredentialVerificationResult
)


class VerificationMethod(str, Enum):
    """Methods for verifying credentials."""
    API_CALL = "api_call"
    TOKEN_VALIDATION = "token_validation"
    SIGNATURE_CHECK = "signature_check"
    EXPIRY_CHECK = "expiry_check"
    PERMISSION_CHECK = "permission_check"
    RATE_LIMIT_CHECK = "rate_limit_check"


class ServiceProvider(str, Enum):
    """Supported service providers."""
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
    GITHUB = "github"
    GITLAB = "gitlab"
    STRIPE = "stripe"
    TWILIO = "twilio"
    SENDGRID = "sendgrid"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    DATABASE = "database"
    CUSTOM = "custom"


class CredentialPermission(BaseModel):
    """Represents a permission associated with a credential."""
    name: str
    scope: str
    granted: bool
    expires_at: Optional[datetime] = None


class VerificationRequest(BaseModel):
    """Request for credential verification."""
    credential_id: str
    verification_methods: List[VerificationMethod]
    service_provider: ServiceProvider
    required_permissions: List[str] = Field(default_factory=list)
    check_rate_limits: bool = True
    metadata: Dict[str, Any] = Field(default_factory=dict)


class VerificationResponse(BaseModel):
    """Response from credential verification."""
    credential_id: str
    is_valid: bool
    status: CredentialStatus
    verification_methods_passed: List[VerificationMethod]
    verification_methods_failed: List[VerificationMethod]
    permissions: List[CredentialPermission] = Field(default_factory=list)
    rate_limit_remaining: Optional[int] = None
    rate_limit_reset_at: Optional[datetime] = None
    error_details: Optional[str] = None
    verified_at: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ICredentialVerifier(Protocol):
    """Protocol for credential verifiers."""
    
    async def verify(
        self,
        credential: Credential,
        request: VerificationRequest
    ) -> VerificationResponse:
        """Verify a credential."""
        ...
    
    async def check_permissions(
        self,
        credential: Credential,
        required_permissions: List[str]
    ) -> List[CredentialPermission]:
        """Check credential permissions."""
        ...
    
    async def check_rate_limits(
        self,
        credential: Credential
    ) -> Tuple[Optional[int], Optional[datetime]]:
        """Check rate limits for credential."""
        ...


class BaseCredentialVerifier(ABC):
    """Base class for credential verifiers."""
    
    def __init__(self, service_provider: ServiceProvider):
        self.service_provider = service_provider
        self.verification_cache: Dict[str, Tuple[datetime, VerificationResponse]] = {}
        self.cache_ttl_seconds = 300  # 5 minutes
    
    @abstractmethod
    async def verify_api_call(self, credential: Credential) -> bool:
        """Verify credential by making an API call."""
        pass
    
    @abstractmethod
    async def verify_token(self, credential: Credential) -> bool:
        """Verify token validity."""
        pass
    
    @abstractmethod
    async def check_permissions(
        self,
        credential: Credential,
        required_permissions: List[str]
    ) -> List[CredentialPermission]:
        """Check credential permissions."""
        pass
    
    @abstractmethod
    async def check_rate_limits(
        self,
        credential: Credential
    ) -> Tuple[Optional[int], Optional[datetime]]:
        """Check rate limits."""
        pass
    
    async def verify(
        self,
        credential: Credential,
        request: VerificationRequest
    ) -> VerificationResponse:
        """
        Verify credential using requested methods.
        
        Args:
            credential: Credential to verify
            request: Verification request with methods and requirements
            
        Returns:
            VerificationResponse with verification results
        """
        # Check cache
        cache_key = f"{credential.id}_{request.service_provider}"
        if cache_key in self.verification_cache:
            cached_time, cached_response = self.verification_cache[cache_key]
            if (datetime.utcnow() - cached_time).seconds < self.cache_ttl_seconds:
                return cached_response
        
        passed_methods = []
        failed_methods = []
        is_valid = True
        error_details = None
        
        # Run verification methods
        for method in request.verification_methods:
            try:
                if method == VerificationMethod.API_CALL:
                    result = await self.verify_api_call(credential)
                elif method == VerificationMethod.TOKEN_VALIDATION:
                    result = await self.verify_token(credential)
                elif method == VerificationMethod.EXPIRY_CHECK:
                    result = not credential.is_expired()
                elif method == VerificationMethod.SIGNATURE_CHECK:
                    result = await self.verify_signature(credential)
                else:
                    result = True  # Default pass for unknown methods
                
                if result:
                    passed_methods.append(method)
                else:
                    failed_methods.append(method)
                    is_valid = False
            
            except Exception as e:
                failed_methods.append(method)
                is_valid = False
                error_details = str(e)
        
        # Check permissions if required
        permissions = []
        if request.required_permissions:
            permissions = await self.check_permissions(
                credential,
                request.required_permissions
            )
            
            # Fail if any required permission is not granted
            if not all(p.granted for p in permissions):
                is_valid = False
        
        # Check rate limits if requested
        rate_limit_remaining = None
        rate_limit_reset_at = None
        if request.check_rate_limits:
            rate_limit_remaining, rate_limit_reset_at = await self.check_rate_limits(credential)
            
            # Fail if rate limit exceeded
            if rate_limit_remaining is not None and rate_limit_remaining <= 0:
                is_valid = False
                error_details = "Rate limit exceeded"
        
        # Determine status
        if is_valid:
            status = CredentialStatus.ACTIVE
        elif credential.is_expired():
            status = CredentialStatus.EXPIRED
        else:
            status = CredentialStatus.INVALID
        
        response = VerificationResponse(
            credential_id=credential.id,
            is_valid=is_valid,
            status=status,
            verification_methods_passed=passed_methods,
            verification_methods_failed=failed_methods,
            permissions=permissions,
            rate_limit_remaining=rate_limit_remaining,
            rate_limit_reset_at=rate_limit_reset_at,
            error_details=error_details
        )
        
        # Cache response
        self.verification_cache[cache_key] = (datetime.utcnow(), response)
        
        return response
    
    async def verify_signature(self, credential: Credential) -> bool:
        """Verify credential signature. Override in subclasses."""
        return True


class AWSCredentialVerifier(BaseCredentialVerifier):
    """Verifier for AWS credentials."""
    
    def __init__(self):
        super().__init__(ServiceProvider.AWS)
    
    async def verify_api_call(self, credential: Credential) -> bool:
        """Verify AWS credentials by making an API call."""
        # Placeholder - would use boto3 to verify
        # Example: sts.get_caller_identity()
        return len(credential.credential_value) > 0
    
    async def verify_token(self, credential: Credential) -> bool:
        """Verify AWS token."""
        # Placeholder - would verify AWS token format
        return credential.credential_type in [
            CredentialType.API_KEY,
            CredentialType.SERVICE_ACCOUNT
        ]
    
    async def check_permissions(
        self,
        credential: Credential,
        required_permissions: List[str]
    ) -> List[CredentialPermission]:
        """Check AWS IAM permissions."""
        # Placeholder - would use IAM policy simulator
        permissions = []
        for perm in required_permissions:
            permissions.append(CredentialPermission(
                name=perm,
                scope="aws",
                granted=True  # Placeholder
            ))
        return permissions
    
    async def check_rate_limits(
        self,
        credential: Credential
    ) -> Tuple[Optional[int], Optional[datetime]]:
        """Check AWS rate limits."""
        # AWS doesn't have global rate limits, service-specific
        return None, None


class GitHubCredentialVerifier(BaseCredentialVerifier):
    """Verifier for GitHub credentials."""
    
    def __init__(self):
        super().__init__(ServiceProvider.GITHUB)
    
    async def verify_api_call(self, credential: Credential) -> bool:
        """Verify GitHub token by making an API call."""
        # Placeholder - would call GitHub API /user endpoint
        return len(credential.credential_value) >= 40
    
    async def verify_token(self, credential: Credential) -> bool:
        """Verify GitHub token format."""
        # GitHub tokens start with ghp_, gho_, etc.
        return credential.credential_value.startswith(('ghp_', 'gho_', 'ghs_', 'ghu_'))
    
    async def check_permissions(
        self,
        credential: Credential,
        required_permissions: List[str]
    ) -> List[CredentialPermission]:
        """Check GitHub token scopes."""
        # Placeholder - would check X-OAuth-Scopes header
        permissions = []
        for perm in required_permissions:
            permissions.append(CredentialPermission(
                name=perm,
                scope="github",
                granted=True  # Placeholder
            ))
        return permissions
    
    async def check_rate_limits(
        self,
        credential: Credential
    ) -> Tuple[Optional[int], Optional[datetime]]:
        """Check GitHub rate limits."""
        # Placeholder - would check X-RateLimit-Remaining header
        return 5000, datetime.utcnow() + timedelta(hours=1)


class DatabaseCredentialVerifier(BaseCredentialVerifier):
    """Verifier for database credentials."""
    
    def __init__(self):
        super().__init__(ServiceProvider.DATABASE)
    
    async def verify_api_call(self, credential: Credential) -> bool:
        """Verify database credentials by attempting connection."""
        # Placeholder - would attempt actual database connection
        return len(credential.credential_value) > 0
    
    async def verify_token(self, credential: Credential) -> bool:
        """Verify database credential format."""
        # Check if it looks like a connection string
        return any(keyword in credential.credential_value.lower() 
                  for keyword in ['host=', 'server=', 'database=', 'mongodb://'])
    
    async def check_permissions(
        self,
        credential: Credential,
        required_permissions: List[str]
    ) -> List[CredentialPermission]:
        """Check database permissions."""
        # Placeholder - would query database for user permissions
        permissions = []
        for perm in required_permissions:
            permissions.append(CredentialPermission(
                name=perm,
                scope="database",
                granted=True  # Placeholder
            ))
        return permissions
    
    async def check_rate_limits(
        self,
        credential: Credential
    ) -> Tuple[Optional[int], Optional[datetime]]:
        """Check database connection limits."""
        # Databases typically don't have rate limits, but connection limits
        return None, None


class CredentialVerifierFactory:
    """Factory for creating credential verifiers."""
    
    _verifiers: Dict[ServiceProvider, BaseCredentialVerifier] = {}
    
    @classmethod
    def register_verifier(
        cls,
        provider: ServiceProvider,
        verifier: BaseCredentialVerifier
    ):
        """Register a verifier for a service provider."""
        cls._verifiers[provider] = verifier
    
    @classmethod
    def get_verifier(cls, provider: ServiceProvider) -> BaseCredentialVerifier:
        """Get verifier for a service provider."""
        if provider not in cls._verifiers:
            # Register default verifiers
            cls._register_default_verifiers()
        
        return cls._verifiers.get(provider)
    
    @classmethod
    def _register_default_verifiers(cls):
        """Register default verifiers."""
        if ServiceProvider.AWS not in cls._verifiers:
            cls.register_verifier(ServiceProvider.AWS, AWSCredentialVerifier())
        
        if ServiceProvider.GITHUB not in cls._verifiers:
            cls.register_verifier(ServiceProvider.GITHUB, GitHubCredentialVerifier())
        
        if ServiceProvider.DATABASE not in cls._verifiers:
            cls.register_verifier(ServiceProvider.DATABASE, DatabaseCredentialVerifier())


class CredentialVerificationInterface:
    """
    Unified interface for credential verification across all services.
    """
    
    def __init__(self):
        self.factory = CredentialVerifierFactory()
        self.verification_history: List[VerificationResponse] = []
    
    async def verify_credential(
        self,
        credential: Credential,
        service_provider: ServiceProvider,
        verification_methods: Optional[List[VerificationMethod]] = None,
        required_permissions: Optional[List[str]] = None,
        check_rate_limits: bool = True
    ) -> VerificationResponse:
        """
        Verify a credential.
        
        Args:
            credential: Credential to verify
            service_provider: Service provider for the credential
            verification_methods: Methods to use for verification
            required_permissions: Required permissions to check
            check_rate_limits: Whether to check rate limits
            
        Returns:
            VerificationResponse with results
        """
        # Default verification methods
        if verification_methods is None:
            verification_methods = [
                VerificationMethod.EXPIRY_CHECK,
                VerificationMethod.TOKEN_VALIDATION,
                VerificationMethod.API_CALL
            ]
        
        # Create verification request
        request = VerificationRequest(
            credential_id=credential.id,
            verification_methods=verification_methods,
            service_provider=service_provider,
            required_permissions=required_permissions or [],
            check_rate_limits=check_rate_limits
        )
        
        # Get appropriate verifier
        verifier = self.factory.get_verifier(service_provider)
        if not verifier:
            return VerificationResponse(
                credential_id=credential.id,
                is_valid=False,
                status=CredentialStatus.INVALID,
                verification_methods_passed=[],
                verification_methods_failed=verification_methods,
                error_details=f"No verifier available for {service_provider}"
            )
        
        # Perform verification
        response = await verifier.verify(credential, request)
        
        # Record in history
        self.verification_history.append(response)
        
        return response
    
    async def batch_verify(
        self,
        credentials: List[Tuple[Credential, ServiceProvider]]
    ) -> List[VerificationResponse]:
        """
        Verify multiple credentials in batch.
        
        Args:
            credentials: List of (credential, service_provider) tuples
            
        Returns:
            List of VerificationResponse objects
        """
        import asyncio
        
        tasks = [
            self.verify_credential(cred, provider)
            for cred, provider in credentials
        ]
        
        return await asyncio.gather(*tasks)
    
    def get_verification_history(
        self,
        credential_id: Optional[str] = None,
        service_provider: Optional[ServiceProvider] = None,
        limit: int = 100
    ) -> List[VerificationResponse]:
        """Get verification history with optional filters."""
        history = self.verification_history
        
        if credential_id:
            history = [h for h in history if h.credential_id == credential_id]
        
        if service_provider:
            # Would need to store provider in response for this filter
            pass
        
        return history[-limit:]
    
    def get_verification_statistics(self) -> Dict[str, Any]:
        """Get statistics about verifications."""
        total = len(self.verification_history)
        
        if total == 0:
            return {
                "total_verifications": 0,
                "success_rate": 0.0,
                "average_methods_per_verification": 0.0
            }
        
        successful = sum(1 for h in self.verification_history if h.is_valid)
        
        total_methods = sum(
            len(h.verification_methods_passed) + len(h.verification_methods_failed)
            for h in self.verification_history
        )
        
        return {
            "total_verifications": total,
            "successful_verifications": successful,
            "failed_verifications": total - successful,
            "success_rate": successful / total,
            "average_methods_per_verification": total_methods / total
        }