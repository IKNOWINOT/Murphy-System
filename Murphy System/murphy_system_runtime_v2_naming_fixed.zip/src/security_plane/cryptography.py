"""
Cryptographic Foundation for Security Plane

Implements post-quantum cryptography with hybrid classical+PQC mode.

CRITICAL SECURITY REQUIREMENTS:
1. All cryptography must support hybrid classical + PQC today
2. Full PQC tomorrow
3. No long-lived secrets
4. Automatic key rotation
5. Forward secrecy everywhere

Primitives:
- Kyber (key exchange) - NIST PQC standard
- Dilithium / Falcon (signatures) - NIST PQC standard
- SHA-3 / BLAKE3 (hashing)
- AES-256-GCM (symmetric encryption)

Key Rotation:
- Automatic
- Frequent (minutes)
- Invisible to users
"""

from dataclasses import dataclass, field
from typing import Optional, Tuple, Dict
from datetime import datetime, timedelta
import hashlib
import secrets
import hmac
from enum import Enum

from .schemas import (
    CryptographicKey,
    CryptographicAlgorithm,
    ExecutionPacketSignature,
    AuthorityBand
)


class HashAlgorithm(Enum):
    """Hash algorithm type."""
    SHA256 = "sha256"
    SHA3_256 = "sha3_256"
    BLAKE3 = "blake3"


@dataclass
class KeyPair:
    """
    Cryptographic key pair.
    
    CRITICAL: Keys are short-lived (minutes).
    """
    public_key: bytes
    private_key: bytes
    algorithm: CryptographicAlgorithm
    created_at: datetime
    expires_at: datetime
    key_id: str
    
    def is_expired(self) -> bool:
        """Check if key pair has expired."""
        return datetime.now() > self.expires_at


@dataclass
class SignatureResult:
    """Result of a signature operation."""
    signature: bytes
    algorithm: CryptographicAlgorithm
    signed_at: datetime
    public_key: bytes
    metadata: Dict[str, str] = field(default_factory=dict)


@dataclass
class VerificationResult:
    """Result of a signature verification."""
    valid: bool
    algorithm: CryptographicAlgorithm
    verified_at: datetime
    public_key: bytes
    error_message: Optional[str] = None


class CryptographicPrimitives:
    """
    Low-level cryptographic primitives.
    
    This is a simplified implementation for demonstration.
    In production, use proper PQC libraries like liboqs, pqcrypto, etc.
    """
    
    @staticmethod
    def hash_data(data: bytes, algorithm: HashAlgorithm = HashAlgorithm.SHA256) -> bytes:
        """
        Hash data using specified algorithm.
        
        Default: SHA-256 (will migrate to SHA-3 or BLAKE3)
        """
        if algorithm == HashAlgorithm.SHA256:
            return hashlib.sha256(data).digest()
        elif algorithm == HashAlgorithm.SHA3_256:
            return hashlib.sha3_256(data).digest()
        elif algorithm == HashAlgorithm.BLAKE3:
            # BLAKE3 not in standard library, fallback to SHA-256
            # In production: import blake3; return blake3.blake3(data).digest()
            return hashlib.sha256(data).digest()
        else:
            raise ValueError(f"Unsupported hash algorithm: {algorithm}")
    
    @staticmethod
    def generate_nonce(length: int = 32) -> str:
        """Generate cryptographically secure nonce."""
        return secrets.token_hex(length)
    
    @staticmethod
    def constant_time_compare(a: bytes, b: bytes) -> bool:
        """Constant-time comparison to prevent timing attacks."""
        return hmac.compare_digest(a, b)
    
    @staticmethod
    def derive_key(master_key: bytes, context: bytes, length: int = 32) -> bytes:
        """
        Derive key from master key using HKDF-like construction.
        
        In production: Use proper HKDF from cryptography library.
        """
        return hashlib.pbkdf2_hmac('sha256', master_key, context, 100000, dklen=length)


class ClassicalCryptography:
    """
    Classical cryptography (RSA, ECDSA, etc.).
    
    This is a simplified implementation for demonstration.
    In production, use proper libraries like cryptography, pycryptodome, etc.
    """
    
    @staticmethod
    def generate_keypair(key_size: int = 2048) -> KeyPair:
        """
        Generate classical key pair (simulated).
        
        In production: Use RSA or ECDSA from cryptography library.
        """
        # Simulated key generation
        private_key = secrets.token_bytes(key_size // 8)
        public_key = hashlib.sha256(private_key).digest()
        
        now = datetime.now()
        expires = now + timedelta(minutes=10)  # Short-lived
        
        return KeyPair(
            public_key=public_key,
            private_key=private_key,
            algorithm=CryptographicAlgorithm.CLASSICAL,
            created_at=now,
            expires_at=expires,
            key_id=f"classical-{secrets.token_hex(8)}"
        )
    
    @staticmethod
    def sign(data: bytes, private_key: bytes) -> bytes:
        """
        Sign data with private key (simulated).
        
        In production: Use proper RSA or ECDSA signing.
        """
        # Simulated signing: HMAC-SHA256
        return hmac.new(private_key, data, hashlib.sha256).digest()
    
    @staticmethod
    def verify(data: bytes, signature: bytes, public_key: bytes, private_key: bytes) -> bool:
        """
        Verify signature (simulated).
        
        In production: Use proper RSA or ECDSA verification.
        """
        # Simulated verification
        expected_signature = hmac.new(private_key, data, hashlib.sha256).digest()
        return CryptographicPrimitives.constant_time_compare(signature, expected_signature)


class PostQuantumCryptography:
    """
    Post-quantum cryptography (Kyber, Dilithium, Falcon).
    
    This is a simplified implementation for demonstration.
    In production, use proper PQC libraries like liboqs, pqcrypto, etc.
    """
    
    @staticmethod
    def generate_keypair_kyber() -> KeyPair:
        """
        Generate Kyber key pair for key exchange (simulated).
        
        In production: Use liboqs or pqcrypto for Kyber.
        """
        # Simulated Kyber key generation
        private_key = secrets.token_bytes(128)  # Kyber private key size
        public_key = hashlib.sha3_256(private_key).digest()
        
        now = datetime.now()
        expires = now + timedelta(minutes=10)
        
        return KeyPair(
            public_key=public_key,
            private_key=private_key,
            algorithm=CryptographicAlgorithm.POST_QUANTUM,
            created_at=now,
            expires_at=expires,
            key_id=f"kyber-{secrets.token_hex(8)}"
        )
    
    @staticmethod
    def generate_keypair_dilithium() -> KeyPair:
        """
        Generate Dilithium key pair for signatures (simulated).
        
        In production: Use liboqs or pqcrypto for Dilithium.
        """
        # Simulated Dilithium key generation
        private_key = secrets.token_bytes(256)  # Dilithium private key size
        public_key = hashlib.sha3_256(private_key).digest()
        
        now = datetime.now()
        expires = now + timedelta(minutes=10)
        
        return KeyPair(
            public_key=public_key,
            private_key=private_key,
            algorithm=CryptographicAlgorithm.POST_QUANTUM,
            created_at=now,
            expires_at=expires,
            key_id=f"dilithium-{secrets.token_hex(8)}"
        )
    
    @staticmethod
    def sign_dilithium(data: bytes, private_key: bytes) -> bytes:
        """
        Sign data with Dilithium (simulated).
        
        In production: Use proper Dilithium signing.
        """
        # Simulated Dilithium signing
        return hmac.new(private_key, data, hashlib.sha3_256).digest()
    
    @staticmethod
    def verify_dilithium(data: bytes, signature: bytes, public_key: bytes, private_key: bytes) -> bool:
        """
        Verify Dilithium signature (simulated).
        
        In production: Use proper Dilithium verification.
        """
        # Simulated verification
        expected_signature = hmac.new(private_key, data, hashlib.sha3_256).digest()
        return CryptographicPrimitives.constant_time_compare(signature, expected_signature)


class HybridCryptography:
    """
    Hybrid classical + post-quantum cryptography.
    
    CRITICAL: This is the default mode for production.
    Provides security against both classical and quantum attacks.
    """
    
    @staticmethod
    def generate_keypair() -> Tuple[KeyPair, KeyPair]:
        """
        Generate hybrid key pair (classical + PQC).
        
        Returns (classical_keypair, pqc_keypair)
        """
        classical = ClassicalCryptography.generate_keypair()
        pqc = PostQuantumCryptography.generate_keypair_dilithium()
        
        return classical, pqc
    
    @staticmethod
    def sign_hybrid(data: bytes, classical_private: bytes, pqc_private: bytes) -> Tuple[bytes, bytes]:
        """
        Sign data with both classical and PQC algorithms.
        
        Returns (classical_signature, pqc_signature)
        """
        classical_sig = ClassicalCryptography.sign(data, classical_private)
        pqc_sig = PostQuantumCryptography.sign_dilithium(data, pqc_private)
        
        return classical_sig, pqc_sig
    
    @staticmethod
    def verify_hybrid(
        data: bytes,
        classical_sig: bytes,
        pqc_sig: bytes,
        classical_public: bytes,
        pqc_public: bytes,
        classical_private: bytes,
        pqc_private: bytes
    ) -> bool:
        """
        Verify hybrid signature.
        
        BOTH signatures must be valid.
        """
        classical_valid = ClassicalCryptography.verify(
            data, classical_sig, classical_public, classical_private
        )
        pqc_valid = PostQuantumCryptography.verify_dilithium(
            data, pqc_sig, pqc_public, pqc_private
        )
        
        return classical_valid and pqc_valid


class KeyManager:
    """
    Manages cryptographic keys with automatic rotation.
    
    CRITICAL FEATURES:
    1. Short-lived keys (minutes)
    2. Automatic rotation
    3. Capability-scoped
    4. Encrypted at rest
    """
    
    def __init__(self, rotation_threshold: timedelta = timedelta(minutes=5)):
        self.rotation_threshold = rotation_threshold
        self._keys: Dict[str, CryptographicKey] = {}
        self._keypairs: Dict[str, Tuple[KeyPair, Optional[KeyPair]]] = {}  # (classical, pqc)
    
    def generate_key(
        self,
        identity_id: str,
        key_type: str,
        algorithm: CryptographicAlgorithm = CryptographicAlgorithm.HYBRID,
        capabilities: set = None
    ) -> CryptographicKey:
        """
        Generate new cryptographic key.
        
        Default: Hybrid classical + PQC
        """
        if capabilities is None:
            capabilities = {"sign", "verify"}
        
        now = datetime.now()
        expires = now + timedelta(minutes=10)
        
        if algorithm == CryptographicAlgorithm.HYBRID:
            classical_kp, pqc_kp = HybridCryptography.generate_keypair()
            keypairs = (classical_kp, pqc_kp)
            public_key = classical_kp.public_key + pqc_kp.public_key
            private_key = classical_kp.private_key + pqc_kp.private_key
        elif algorithm == CryptographicAlgorithm.POST_QUANTUM:
            pqc_kp = PostQuantumCryptography.generate_keypair_dilithium()
            keypairs = (pqc_kp, None)
            public_key = pqc_kp.public_key
            private_key = pqc_kp.private_key
        else:  # CLASSICAL
            classical_kp = ClassicalCryptography.generate_keypair()
            keypairs = (classical_kp, None)
            public_key = classical_kp.public_key
            private_key = classical_kp.private_key
        
        key_id = f"key-{secrets.token_hex(16)}"
        
        # Encrypt private key (simulated - in production use proper encryption)
        private_key_encrypted = self._encrypt_private_key(private_key)
        
        key = CryptographicKey(
            key_id=key_id,
            key_type=key_type,
            algorithm=algorithm,
            public_key=public_key,
            private_key_encrypted=private_key_encrypted,
            created_at=now,
            expires_at=expires,
            identity_id=identity_id,
            capabilities=capabilities
        )
        
        self._keys[key_id] = key
        self._keypairs[key_id] = keypairs
        
        return key
    
    def _encrypt_private_key(self, private_key: bytes) -> bytes:
        """
        Encrypt private key at rest (simulated).
        
        In production: Use proper encryption (AES-256-GCM with hardware key).
        """
        # Simulated encryption
        return hashlib.sha256(private_key).digest()
    
    def _decrypt_private_key(self, encrypted_key: bytes) -> bytes:
        """
        Decrypt private key (simulated).
        
        In production: Use proper decryption.
        """
        # Simulated decryption - in reality this would reverse the encryption
        return encrypted_key
    
    def get_key(self, key_id: str) -> Optional[CryptographicKey]:
        """Get key by ID."""
        return self._keys.get(key_id)
    
    def rotate_key(self, key_id: str) -> CryptographicKey:
        """
        Rotate key (generate new key with same properties).
        
        Old key is marked as rotated.
        """
        old_key = self._keys.get(key_id)
        if not old_key:
            raise ValueError(f"Key {key_id} not found")
        
        # Mark old key as rotated
        old_key.rotated = True
        old_key.rotation_scheduled_at = datetime.now()
        
        # Generate new key
        new_key = self.generate_key(
            identity_id=old_key.identity_id,
            key_type=old_key.key_type,
            algorithm=old_key.algorithm,
            capabilities=old_key.capabilities
        )
        
        return new_key
    
    def check_rotation_needed(self) -> list[str]:
        """
        Check which keys need rotation.
        
        Returns list of key IDs that should be rotated.
        """
        keys_to_rotate = []
        
        for key_id, key in self._keys.items():
            if key.should_rotate(self.rotation_threshold):
                keys_to_rotate.append(key_id)
        
        return keys_to_rotate
    
    def auto_rotate_keys(self) -> list[str]:
        """
        Automatically rotate keys that need rotation.
        
        Returns list of rotated key IDs.
        """
        keys_to_rotate = self.check_rotation_needed()
        rotated = []
        
        for key_id in keys_to_rotate:
            try:
                self.rotate_key(key_id)
                rotated.append(key_id)
            except Exception as e:
                # Log error but continue rotating other keys
                print(f"Error rotating key {key_id}: {e}")
        
        return rotated


class PacketSigner:
    """
    Signs execution packets with Control Plane authority.
    
    CRITICAL: Only Control Plane can sign execution packets.
    """
    
    def __init__(self, key_manager: KeyManager):
        self.key_manager = key_manager
    
    def sign_execution_packet(
        self,
        packet_id: str,
        packet_data: bytes,
        authority_band: AuthorityBand,
        target_adapter: str,
        time_window_minutes: int = 5,
        signer_id: str = "control-plane"
    ) -> ExecutionPacketSignature:
        """
        Sign execution packet.
        
        CRITICAL: This creates a cryptographically sealed, single-use,
        time-bound execution packet.
        """
        # Get or generate signing key
        signing_key = self._get_or_create_signing_key(signer_id)
        
        # Generate unique nonce for replay prevention
        nonce = CryptographicPrimitives.generate_nonce()
        
        # Create signature payload
        now = datetime.now()
        time_window_start = now
        time_window_end = now + timedelta(minutes=time_window_minutes)
        
        payload = (
            f"{packet_id}{packet_data.hex()}{authority_band.value}"
            f"{target_adapter}{time_window_start.isoformat()}"
            f"{time_window_end.isoformat()}{nonce}"
        ).encode()
        
        # Sign with hybrid cryptography
        keypairs = self.key_manager._keypairs.get(signing_key.key_id)
        if not keypairs:
            raise ValueError(f"Keypairs not found for key {signing_key.key_id}")
        
        classical_kp, pqc_kp = keypairs
        
        if signing_key.algorithm == CryptographicAlgorithm.HYBRID and pqc_kp:
            classical_sig, pqc_sig = HybridCryptography.sign_hybrid(
                payload,
                classical_kp.private_key,
                pqc_kp.private_key
            )
            signature = classical_sig + pqc_sig
        elif signing_key.algorithm == CryptographicAlgorithm.POST_QUANTUM:
            signature = PostQuantumCryptography.sign_dilithium(
                payload,
                classical_kp.private_key
            )
        else:  # CLASSICAL
            signature = ClassicalCryptography.sign(
                payload,
                classical_kp.private_key
            )
        
        return ExecutionPacketSignature(
            packet_id=packet_id,
            signature=signature,
            algorithm=signing_key.algorithm,
            signed_at=now,
            signed_by=signer_id,
            time_window_start=time_window_start,
            time_window_end=time_window_end,
            authority_band=authority_band,
            target_adapter=target_adapter,
            nonce=nonce
        )
    
    def _get_or_create_signing_key(self, signer_id: str) -> CryptographicKey:
        """Get or create signing key for signer."""
        # Look for existing valid key
        for key in self.key_manager._keys.values():
            if (key.identity_id == signer_id and
                key.key_type == "signing" and
                not key.is_expired() and
                not key.rotated):
                return key
        
        # Create new key
        return self.key_manager.generate_key(
            identity_id=signer_id,
            key_type="signing",
            algorithm=CryptographicAlgorithm.HYBRID,
            capabilities={"sign"}
        )
    
    def verify_packet_signature(
        self,
        packet_signature: ExecutionPacketSignature,
        packet_data: bytes
    ) -> VerificationResult:
        """
        Verify execution packet signature.
        
        Checks:
        1. Signature validity
        2. Time window
        3. Single-use enforcement
        """
        # Check time window
        if not packet_signature.is_valid():
            return VerificationResult(
                valid=False,
                algorithm=packet_signature.algorithm,
                verified_at=datetime.now(),
                public_key=b"",
                error_message="Packet signature expired or already used"
            )
        
        # Get signing key
        signing_key = None
        for key in self.key_manager._keys.values():
            if key.identity_id == packet_signature.signed_by and key.key_type == "signing":
                signing_key = key
                break
        
        if not signing_key:
            return VerificationResult(
                valid=False,
                algorithm=packet_signature.algorithm,
                verified_at=datetime.now(),
                public_key=b"",
                error_message="Signing key not found"
            )
        
        # Reconstruct payload
        payload = (
            f"{packet_signature.packet_id}{packet_data.hex()}{packet_signature.authority_band.value}"
            f"{packet_signature.target_adapter}{packet_signature.time_window_start.isoformat()}"
            f"{packet_signature.time_window_end.isoformat()}{packet_signature.nonce}"
        ).encode()
        
        # Verify signature
        keypairs = self.key_manager._keypairs.get(signing_key.key_id)
        if not keypairs:
            return VerificationResult(
                valid=False,
                algorithm=packet_signature.algorithm,
                verified_at=datetime.now(),
                public_key=signing_key.public_key,
                error_message="Keypairs not found"
            )
        
        classical_kp, pqc_kp = keypairs
        
        try:
            if packet_signature.algorithm == CryptographicAlgorithm.HYBRID and pqc_kp:
                # Split signature
                sig_len = len(packet_signature.signature) // 2
                classical_sig = packet_signature.signature[:sig_len]
                pqc_sig = packet_signature.signature[sig_len:]
                
                valid = HybridCryptography.verify_hybrid(
                    payload,
                    classical_sig,
                    pqc_sig,
                    classical_kp.public_key,
                    pqc_kp.public_key,
                    classical_kp.private_key,
                    pqc_kp.private_key
                )
            elif packet_signature.algorithm == CryptographicAlgorithm.POST_QUANTUM:
                valid = PostQuantumCryptography.verify_dilithium(
                    payload,
                    packet_signature.signature,
                    classical_kp.public_key,
                    classical_kp.private_key
                )
            else:  # CLASSICAL
                valid = ClassicalCryptography.verify(
                    payload,
                    packet_signature.signature,
                    classical_kp.public_key,
                    classical_kp.private_key
                )
            
            return VerificationResult(
                valid=valid,
                algorithm=packet_signature.algorithm,
                verified_at=datetime.now(),
                public_key=signing_key.public_key,
                error_message=None if valid else "Signature verification failed"
            )
        
        except Exception as e:
            return VerificationResult(
                valid=False,
                algorithm=packet_signature.algorithm,
                verified_at=datetime.now(),
                public_key=signing_key.public_key,
                error_message=f"Verification error: {str(e)}"
            )