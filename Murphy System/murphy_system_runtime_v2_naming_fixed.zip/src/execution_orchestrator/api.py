"""
Execution Orchestrator REST API
================================

Flask API server for the Execution Orchestrator service.

Endpoints:
- POST /execute - Execute sealed packet
- GET /execution/{packet_id} - Get execution status
- POST /pause/{packet_id} - Pause execution
- POST /resume/{packet_id} - Resume execution
- POST /abort/{packet_id} - Abort execution
- GET /telemetry/{packet_id} - Get telemetry stream
- GET /risk/{packet_id} - Get runtime risk
- GET /certificate/{packet_id} - Get completion certificate
- GET /interfaces - Get interface status
- POST /interfaces/register - Register interface
- GET /health - Health check
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime
import threading
from typing import Dict, Optional

from .models import (
    ExecutionState,
    ExecutionStatus,
    StepResult,
    InterfaceHealth,
    TelemetryEventType
)
from .validator import PreExecutionValidator
from .executor import StepwiseExecutor
from .telemetry import TelemetryStreamer
from .risk_monitor import RuntimeRiskMonitor
from .rollback import RollbackEnforcer
from .completion import CompletionCertifier


app = Flask(__name__)
CORS(app)

# Initialize components
validator = PreExecutionValidator()
executor = StepwiseExecutor()
telemetry = TelemetryStreamer()
risk_monitor = RuntimeRiskMonitor()
rollback_enforcer = RollbackEnforcer()
completion_certifier = CompletionCertifier()

# Execution state registry
executions: Dict[str, ExecutionState] = {}
execution_locks: Dict[str, threading.Lock] = {}


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'execution_orchestrator',
        'timestamp': datetime.now().isoformat(),
        'active_executions': len(executions),
        'components': {
            'validator': 'operational',
            'executor': 'operational',
            'telemetry': 'operational',
            'risk_monitor': 'operational',
            'rollback_enforcer': 'operational',
            'completion_certifier': 'operational'
        }
    })


@app.route('/execute', methods=['POST'])
def execute_packet():
    """
    Execute sealed packet
    
    Request body:
    {
        "packet": {...},
        "authority_level": "standard"
    }
    """
    data = request.json
    packet = data.get('packet', {})
    authority_level = data.get('authority_level', 'standard')
    
    packet_id = packet.get('packet_id', '')
    expected_signature = packet.get('signature', '')
    
    # Check if already executing
    if packet_id in executions:
        return jsonify({
            'error': 'Packet is already being executed'
        }), 400
    
    # Validate packet
    all_valid, errors = validator.validate_all(
        packet,
        expected_signature,
        authority_level
    )
    
    if not all_valid:
        return jsonify({
            'error': 'Validation failed',
            'errors': errors
        }), 400
    
    # Create execution state
    execution_state = ExecutionState(
        packet_id=packet_id,
        packet_signature=expected_signature,
        status=ExecutionStatus.PENDING,
        current_step=0,
        total_steps=len(packet.get('execution_graph', {}).get('steps', [])),
        start_time=datetime.now()
    )
    
    executions[packet_id] = execution_state
    execution_locks[packet_id] = threading.Lock()
    
    # Start execution in background thread
    thread = threading.Thread(
        target=_execute_packet_async,
        args=(packet, execution_state)
    )
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'packet_id': packet_id,
        'status': 'started',
        'execution_state': execution_state.to_dict()
    })


def _execute_packet_async(packet: Dict, execution_state: ExecutionState):
    """Execute packet asynchronously"""
    packet_id = packet['packet_id']
    
    try:
        # Initialize monitoring
        base_risk = packet.get('expected_loss', 0.0)
        initial_confidence = packet.get('confidence', 0.8)
        
        risk_monitor.initialize_monitoring(
            packet_id,
            base_risk,
            initial_confidence
        )
        
        # Create telemetry stream
        telemetry.create_stream(packet_id)
        
        # Emit execution start
        telemetry.emit_execution_start(
            packet_id,
            execution_state.total_steps,
            base_risk,
            initial_confidence
        )
        
        # Update status
        execution_state.status = ExecutionStatus.RUNNING
        
        # Execute steps
        steps = packet.get('execution_graph', {}).get('steps', [])
        context = {}
        
        for i, step in enumerate(steps):
            # Check if should pause
            if risk_monitor.should_pause(packet_id):
                execution_state.status = ExecutionStatus.PAUSED
                stop_conditions = risk_monitor.get_stop_conditions(packet_id)
                
                telemetry.emit_execution_paused(
                    packet_id,
                    f"Safety threshold breached: {len(stop_conditions)} conditions",
                    risk_monitor.get_safety_state(packet_id).current_risk,
                    risk_monitor.get_safety_state(packet_id).current_confidence
                )
                
                # Execute rollback
                _execute_rollback(packet, execution_state)
                return
            
            # Emit step start
            telemetry.emit_step_start(
                packet_id,
                step.get('step_id', ''),
                i,
                step.get('type', ''),
                risk_monitor.get_safety_state(packet_id).current_risk,
                risk_monitor.get_safety_state(packet_id).current_confidence
            )
            
            # Execute step
            step_result = executor.execute_step(step, context)
            execution_state.results.append(step_result)
            execution_state.current_step = i + 1
            
            # Update context with step output
            if step_result.success and step_result.output:
                output_var = step.get('output_variable')
                if output_var:
                    context[output_var] = step_result.output
            
            # Update monitoring
            new_confidence = initial_confidence + step_result.confidence_delta
            safety_state = risk_monitor.update_after_step(
                packet_id,
                step_result,
                new_confidence
            )
            
            # Emit step complete/failed
            if step_result.success:
                telemetry.emit_step_complete(
                    packet_id,
                    step_result,
                    safety_state.current_risk,
                    safety_state.current_confidence
                )
            else:
                telemetry.emit_step_failed(
                    packet_id,
                    step_result,
                    safety_state.current_risk,
                    safety_state.current_confidence
                )
                
                # Step failed - execute rollback
                execution_state.status = ExecutionStatus.FAILED
                execution_state.error = step_result.error
                _execute_rollback(packet, execution_state)
                return
        
        # All steps completed successfully
        execution_state.status = ExecutionStatus.COMPLETED
        execution_state.end_time = datetime.now()
        
        # Get final metrics
        final_risk = risk_monitor.get_safety_state(packet_id).current_risk
        final_confidence = risk_monitor.get_safety_state(packet_id).current_confidence
        
        # Generate completion certificate
        artifacts_created = packet.get('artifacts_created', [])
        artifacts_modified = packet.get('artifacts_modified', [])
        
        certificate = completion_certifier.generate_certificate(
            execution_state,
            final_risk,
            final_confidence,
            artifacts_created,
            artifacts_modified
        )
        
        # Emit execution complete
        telemetry.emit_execution_complete(
            packet_id,
            execution_state.total_steps,
            sum(1 for r in execution_state.results if r.success),
            final_risk,
            final_confidence
        )
        
    except Exception as e:
        execution_state.status = ExecutionStatus.FAILED
        execution_state.error = str(e)
        execution_state.end_time = datetime.now()
        
        telemetry.emit_execution_failed(
            packet_id,
            str(e),
            risk_monitor.get_safety_state(packet_id).current_risk if packet_id in risk_monitor.safety_states else 0.0,
            risk_monitor.get_safety_state(packet_id).current_confidence if packet_id in risk_monitor.safety_states else 0.0
        )


def _execute_rollback(packet: Dict, execution_state: ExecutionState):
    """Execute rollback for failed execution"""
    packet_id = packet['packet_id']
    
    # Emit rollback start
    telemetry.emit_rollback_start(
        packet_id,
        execution_state.error or "Unknown error",
        risk_monitor.get_safety_state(packet_id).current_risk,
        risk_monitor.get_safety_state(packet_id).current_confidence
    )
    
    # Execute rollback
    rollback_plan = packet.get('rollback_plan', {})
    success, errors = rollback_enforcer.execute_rollback(
        packet_id,
        execution_state.results,
        rollback_plan
    )
    
    # Emit rollback complete
    telemetry.emit_rollback_complete(
        packet_id,
        success,
        risk_monitor.get_safety_state(packet_id).current_risk,
        risk_monitor.get_safety_state(packet_id).current_confidence
    )
    
    if not success:
        execution_state.error = f"Rollback failed: {', '.join(errors)}"


@app.route('/execution/<packet_id>', methods=['GET'])
def get_execution_status(packet_id: str):
    """Get execution status"""
    if packet_id not in executions:
        return jsonify({'error': 'Execution not found'}), 404
    
    execution_state = executions[packet_id]
    
    return jsonify({
        'execution_state': execution_state.to_dict(),
        'safety_state': risk_monitor.get_safety_state(packet_id).to_dict() if packet_id in risk_monitor.safety_states else None,
        'runtime_risk': risk_monitor.get_runtime_risk(packet_id).to_dict() if packet_id in risk_monitor.runtime_risks else None
    })


@app.route('/telemetry/<packet_id>', methods=['GET'])
def get_telemetry(packet_id: str):
    """Get telemetry stream"""
    stream = telemetry.get_stream(packet_id)
    
    if not stream:
        return jsonify({'error': 'Telemetry stream not found'}), 404
    
    return jsonify({
        'stream': stream.to_dict(),
        'metrics': telemetry.get_aggregated_metrics(packet_id)
    })


@app.route('/telemetry', methods=['GET'])
def get_system_telemetry():
    """Get system-wide telemetry for Recursive Stability Controller"""
    # Get all active packets
    active_packets = [p for p in executor.packets.values() 
                     if p.status in ['planning', 'executing']]
    
    # Count by authority level
    authority_levels = {'none': 0, 'low': 0, 'medium': 0, 'high': 0, 'full': 0}
    for packet in active_packets:
        auth = packet.authority_level
        if auth in authority_levels:
            authority_levels[auth] += 1
    
    # Count by status
    executing_packets = sum(1 for p in executor.packets.values() if p.status == 'executing')
    queued_packets = sum(1 for p in executor.packets.values() if p.status == 'queued')
    failed_packets = sum(1 for p in executor.packets.values() if p.status == 'failed')
    
    # Active agents = packets with authority > none
    active_agents = sum(1 for p in active_packets if p.authority_level != 'none')
    
    return jsonify({
        'active_agents': active_agents,
        'executing_packets': executing_packets,
        'queued_packets': queued_packets,
        'failed_packets': failed_packets,
        'authority_levels': authority_levels,
        'total_packets': len(executor.packets)
    })


@app.route('/risk/<packet_id>', methods=['GET'])
def get_runtime_risk(packet_id: str):
    """Get runtime risk"""
    summary = risk_monitor.get_monitoring_summary(packet_id)
    
    if not summary:
        return jsonify({'error': 'Risk monitoring not found'}), 404
    
    return jsonify(summary)


@app.route('/certificate/<packet_id>', methods=['GET'])
def get_certificate(packet_id: str):
    """Get completion certificate"""
    certificate = completion_certifier.get_certificate(packet_id)
    
    if not certificate:
        return jsonify({'error': 'Certificate not found'}), 404
    
    return jsonify({
        'certificate': certificate.to_dict(),
        'verified': completion_certifier.verify_certificate(certificate)
    })


@app.route('/interfaces', methods=['GET'])
def get_interfaces():
    """Get interface status"""
    status = validator.get_interface_status()
    
    return jsonify(status.to_dict())


@app.route('/interfaces/register', methods=['POST'])
def register_interface():
    """Register interface"""
    data = request.json
    
    health = InterfaceHealth(
        interface_id=data.get('interface_id', ''),
        is_available=data.get('is_available', True),
        response_time_ms=data.get('response_time_ms', 0.0),
        error_rate=data.get('error_rate', 0.0),
        last_check=datetime.now()
    )
    
    validator.register_interface(health)
    
    return jsonify({
        'status': 'registered',
        'interface': health.to_dict()
    })


@app.route('/abort/<packet_id>', methods=['POST'])
def abort_execution(packet_id: str):
    """Abort execution"""
    if packet_id not in executions:
        return jsonify({'error': 'Execution not found'}), 404
    
    execution_state = executions[packet_id]
    execution_state.status = ExecutionStatus.ABORTED
    execution_state.end_time = datetime.now()
    
    return jsonify({
        'status': 'aborted',
        'execution_state': execution_state.to_dict()
    })


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8058, debug=False)