"""
LLM Integration Layer
Integrates local LLMs with MFGC system for enhanced reasoning
"""

import os
import json
from typing import Dict, Any, Optional, List
from enum import Enum


class LLMProvider(Enum):
    """Available LLM providers"""
    OLLAMA = "ollama"  # Local Ollama models
    TRANSFORMERS = "transformers"  # Hugging Face transformers
    LLAMACPP = "llamacpp"  # llama.cpp Python bindings
    NONE = "none"  # Rule-based only


class LLMConfig:
    """LLM configuration"""
    
    # Recommended models by size (for 4GB RAM system)
    MODELS = {
        'tiny': {
            'name': 'tinyllama',
            'size': '1.1B',
            'ram': '1.5GB',
            'provider': LLMProvider.OLLAMA,
            'description': 'TinyLlama 1.1B - Fast, minimal RAM'
        },
        'small': {
            'name': 'phi',
            'size': '2.7B',
            'ram': '2.5GB',
            'provider': LLMProvider.OLLAMA,
            'description': 'Microsoft Phi-2 - Best quality for size'
        },
        'medium': {
            'name': 'mistral',
            'size': '7B',
            'ram': '4.5GB',
            'provider': LLMProvider.OLLAMA,
            'description': 'Mistral 7B - High quality (needs 8GB+ RAM)'
        }
    }
    
    @classmethod
    def get_recommended_model(cls, available_ram_gb: float) -> str:
        """Get recommended model based on available RAM"""
        if available_ram_gb >= 6:
            return 'medium'
        elif available_ram_gb >= 3:
            return 'small'
        else:
            return 'tiny'


class OllamaLLM:
    """
    Ollama LLM integration
    
    Ollama is the easiest way to run local LLMs:
    - Simple installation
    - Automatic model management
    - Good performance
    - Multiple model support
    """
    
    def __init__(self, model_name: str = "phi"):
        """
        Initialize Ollama LLM
        
        Args:
            model_name: Ollama model name (tinyllama, phi, mistral, etc.)
        """
        self.model_name = model_name
        self.base_url = "http://localhost:11434"
        
        # Check if Ollama is available
        self.available = self._check_ollama()
        
        if self.available:
            print(f"✓ Ollama available with model: {model_name}")
        else:
            print("⚠ Ollama not available - install with: curl -fsSL https://ollama.com/install.sh | sh")
    
    def _check_ollama(self) -> bool:
        """Check if Ollama is running"""
        try:
            import requests
            response = requests.get(f"{self.base_url}/api/tags", timeout=2)
            return response.status_code == 200
        except:
            return False
    
    def generate(self, prompt: str, system_prompt: Optional[str] = None, 
                max_tokens: int = 500, temperature: float = 0.7) -> str:
        """
        Generate text using Ollama
        
        Args:
            prompt: User prompt
            system_prompt: Optional system prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0.0-1.0)
        
        Returns:
            Generated text
        """
        if not self.available:
            return "[Ollama not available - using fallback]"
        
        try:
            import requests
            
            payload = {
                "model": self.model_name,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": temperature,
                    "num_predict": max_tokens
                }
            }
            
            if system_prompt:
                payload["system"] = system_prompt
            
            response = requests.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return result.get("response", "")
            else:
                return f"[Error: {response.status_code}]"
        
        except Exception as e:
            return f"[Error: {str(e)}]"
    
    def chat(self, messages: List[Dict[str, str]], 
            max_tokens: int = 500, temperature: float = 0.7) -> str:
        """
        Chat completion using Ollama
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
        
        Returns:
            Assistant response
        """
        if not self.available:
            return "[Ollama not available - using fallback]"
        
        try:
            import requests
            
            payload = {
                "model": self.model_name,
                "messages": messages,
                "stream": False,
                "options": {
                    "temperature": temperature,
                    "num_predict": max_tokens
                }
            }
            
            response = requests.post(
                f"{self.base_url}/api/chat",
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return result.get("message", {}).get("content", "")
            else:
                return f"[Error: {response.status_code}]"
        
        except Exception as e:
            return f"[Error: {str(e)}]"


class LLMEnhancedMFGC:
    """
    MFGC system enhanced with LLM reasoning
    
    Uses LLM for:
    1. Candidate generation (more creative solutions)
    2. Risk analysis (better risk identification)
    3. Gate synthesis (more comprehensive gates)
    4. Natural language understanding
    """
    
    def __init__(self, llm_provider: LLMProvider = LLMProvider.OLLAMA,
                 model_name: str = "phi"):
        """
        Initialize LLM-enhanced MFGC
        
        Args:
            llm_provider: LLM provider to use
            model_name: Model name for the provider
        """
        self.llm_provider = llm_provider
        
        if llm_provider == LLMProvider.OLLAMA:
            self.llm = OllamaLLM(model_name)
        else:
            self.llm = None
            print("⚠ No LLM provider - using rule-based fallback")
    
    def generate_candidates(self, task: str, phase: str, 
                          existing_candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Generate solution candidates using LLM
        
        Args:
            task: Task description
            phase: Current MFGC phase
            existing_candidates: Candidates from rule-based system
        
        Returns:
            Enhanced list of candidates
        """
        if not self.llm or not self.llm.available:
            return existing_candidates
        
        prompt = f"""Task: {task}
Phase: {phase}

Generate 3-5 creative solution approaches for this task in the {phase} phase.
Focus on practical, implementable solutions.

Format your response as JSON:
[
  {{"approach": "...", "pros": ["..."], "cons": ["..."], "score": 0.0-1.0}},
  ...
]"""
        
        response = self.llm.generate(prompt, temperature=0.8, max_tokens=500)
        
        # Try to parse JSON response
        try:
            llm_candidates = json.loads(response)
            if isinstance(llm_candidates, list):
                # Merge with existing candidates
                return existing_candidates + llm_candidates
        except:
            pass
        
        return existing_candidates
    
    def analyze_risks(self, task: str, candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Analyze risks using LLM
        
        Args:
            task: Task description
            candidates: Solution candidates
        
        Returns:
            List of identified risks
        """
        if not self.llm or not self.llm.available:
            return []
        
        prompt = f"""Task: {task}

Candidates:
{json.dumps(candidates, indent=2)}

Identify potential risks and failure modes for these solutions.
Consider: technical risks, business risks, security risks, operational risks.

Format as JSON:
[
  {{"risk": "...", "probability": 0.0-1.0, "impact": 0.0-1.0, "mitigation": "..."}},
  ...
]"""
        
        response = self.llm.generate(prompt, temperature=0.5, max_tokens=500)
        
        try:
            risks = json.loads(response)
            if isinstance(risks, list):
                return risks
        except:
            pass
        
        return []
    
    def synthesize_gates(self, task: str, risks: List[Dict[str, Any]]) -> List[str]:
        """
        Synthesize control gates using LLM
        
        Args:
            task: Task description
            risks: Identified risks
        
        Returns:
            List of control gates
        """
        if not self.llm or not self.llm.available:
            return []
        
        prompt = f"""Task: {task}

Risks:
{json.dumps(risks, indent=2)}

Generate specific, actionable control gates to prevent these risks.
Each gate should be a clear checkpoint or validation step.

Format as JSON array of strings:
["Gate 1", "Gate 2", ...]"""
        
        response = self.llm.generate(prompt, temperature=0.3, max_tokens=300)
        
        try:
            gates = json.loads(response)
            if isinstance(gates, list):
                return [str(g) for g in gates]
        except:
            pass
        
        return []
    
    def enhance_conversation(self, message: str, context: Dict[str, Any]) -> str:
        """
        Enhance conversation responses using LLM
        
        Args:
            message: User message
            context: Conversation context
        
        Returns:
            Enhanced response
        """
        if not self.llm or not self.llm.available:
            return None
        
        messages = [
            {
                "role": "system",
                "content": "You are a helpful AI assistant integrated with a Murphy-Free Generative Control system. Provide clear, accurate, and helpful responses."
            },
            {
                "role": "user",
                "content": message
            }
        ]
        
        response = self.llm.chat(messages, temperature=0.7, max_tokens=500)
        return response


def get_system_info() -> Dict[str, Any]:
    """Get system information for LLM selection"""
    import psutil
    
    # Get available RAM
    mem = psutil.virtual_memory()
    available_ram_gb = mem.available / (1024**3)
    
    return {
        'available_ram_gb': available_ram_gb,
        'total_ram_gb': mem.total / (1024**3),
        'cpu_count': os.cpu_count(),
        'recommended_model': LLMConfig.get_recommended_model(available_ram_gb)
    }


def print_installation_guide():
    """Print installation guide for Ollama"""
    print("""
╔══════════════════════════════════════════════════════════════╗
║              LLM Enhancement Installation Guide              ║
╚══════════════════════════════════════════════════════════════╝

To enable LLM-enhanced MFGC, install Ollama:

1. Install Ollama:
   curl -fsSL https://ollama.com/install.sh | sh

2. Start Ollama (if not auto-started):
   ollama serve

3. Pull a model (choose based on your RAM):
   
   For 2-4GB RAM (Recommended for this system):
   ollama pull phi
   
   For 1-2GB RAM (Minimal):
   ollama pull tinyllama
   
   For 8GB+ RAM (Best quality):
   ollama pull mistral

4. Restart the MFGC server

Models will be downloaded automatically on first use.

Current system specs:
""")
    
    info = get_system_info()
    print(f"  • Available RAM: {info['available_ram_gb']:.1f} GB")
    print(f"  • Total RAM: {info['total_ram_gb']:.1f} GB")
    print(f"  • CPU cores: {info['cpu_count']}")
    print(f"  • Recommended model: {info['recommended_model']}")
    print()


if __name__ == "__main__":
    print_installation_guide()