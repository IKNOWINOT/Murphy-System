Murphy System Demo Package

This package contains everything you need to demo Murphy System 1.0.

Files included:
- demo_simple.py: Quick demo (no server required) ⚡
- demo_murphy.py: Full demo suite (requires server)
- start.sh: Start Murphy server
- MURPHY_NOW_WORKING.md: User guide
- DEMO_GUIDE.md: Complete demo instructions
- VS_CODE_DEMO_COMPLETE.md: VS Code integration guide
- requirements_murphy_1.0.txt: Python dependencies

Quick Start:
2. Or: ./start.sh (then visit http://localhost:6666/docs)
3. Or: python demo_murphy.py --demo quick

For more info, see MURPHY_NOW_WORKING.md

